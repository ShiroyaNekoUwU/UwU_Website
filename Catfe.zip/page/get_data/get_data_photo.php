<?php
$sql_photo = "SELECT * FROM photo";
$result_photo = $conn->query($sql_photo);
?>
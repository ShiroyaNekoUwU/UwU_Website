<footer>
        <p>&copy; 2024 Catfe. All rights reserved.</p>
        <ul>
            <li><a href="PrivacyPolicy.html">Privacy Policy</a></li>
            <li><a href="TermsOfService.html">Terms of Service</a></li>
        </ul>
</footer>
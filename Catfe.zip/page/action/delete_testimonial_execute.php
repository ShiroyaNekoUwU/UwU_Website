<?php
include("../../connect.php");

if(isset($_GET['testimonial'])){
    $testimonial = $_GET['testimonial'];
}else{
    $testimonial = 'B0000';
}

$sql_delete_testimonial_execute = "DELETE FROM testimonial WHERE testimonial_id = '$testimonial'";
$conn->query("SET FOREIGN_KEY_CHECKS=0");
if (($conn->query($sql_delete_testimonial_execute) === TRUE)) {
    $conn->query("SET FOREIGN_KEY_CHECKS=1");
    echo "<script>alert('Successfully deleted data!');</script>";
    echo "<script>window.location.href = '../list_testimonial.php';</script>";
}else{
    $conn->query("SET FOREIGN_KEY_CHECKS=1");
    echo "<script>alert('Something was wrong!');</script>";
    echo "<script>window.location.href = '../list_testimonial.php';</script>";
}
?>
